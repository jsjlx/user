
//根据页面div距离浏览器窗口的距离进行动画
function getTop(clsName){ 
            var obj = document.getElementsByClassName(clsName)[0];
            return obj.getBoundingClientRect().top;
        }
        function getDom(clsName){
            var obj=document.getElementsByClassName(clsName)[0];
            return obj;
        }

function getTop(clsName){ 
            var obj = document.getElementsByClassName(clsName)[0];
            return obj.getBoundingClientRect().top;
        }
        function getDom(clsName){
            var obj=document.getElementsByClassName(clsName)[0];
            return obj;
        }

        
        window.addEventListener('scroll',function(){
            var scrollT=document.documentElement.scrollTop||document.body.scrollTop;

            if(getTop('inform-group')<860){
                getDom('inform-group').classList.add('animated');
                getDom('inform-group').classList.add('fadeInDown');
            };
        
  })